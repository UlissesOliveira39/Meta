//
//  Meta.h
//  Meta
//
//  Created by Sean Thielen on 2/9/18.
//  Copyright © 2018 GoMeta. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Meta.
FOUNDATION_EXPORT double MetaVersionNumber;

//! Project version string for Meta.
FOUNDATION_EXPORT const unsigned char MetaVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Meta/PublicHeader.h>

