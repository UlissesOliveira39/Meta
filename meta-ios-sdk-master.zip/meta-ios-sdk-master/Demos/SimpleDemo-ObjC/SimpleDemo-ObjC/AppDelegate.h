//
//  AppDelegate.h
//  SimpleDemo-ObjC
//
//  Created by Sean Thielen on 5/22/18.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

