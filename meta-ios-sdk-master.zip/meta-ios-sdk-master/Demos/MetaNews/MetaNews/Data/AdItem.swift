//
//  AdItem.swift
//  MetaNews
//
//  Created by Sean Thielen on 2/11/18.
//  Copyright © 2018 GoMeta. All rights reserved.
//

import UIKit

struct AdItem {
    let image: UIImage?
    let experience: String
}
